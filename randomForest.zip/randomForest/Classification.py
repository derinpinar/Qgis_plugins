# -*- coding: utf-8 -*-
"""
/***************************************************************************
 randomForest
                                 A QGIS plugin
 Classification with Random Forest Algorithm
                              -------------------
        begin                : 2017-02-15
        git sha              : $Format:%H$
        copyright            : (C) 2017 by www.derinpinar.net
        email                : andacderinpinar@gmail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from PyQt4.QtCore import QSettings, QTranslator, qVersion, QCoreApplication
from PyQt4.QtGui import QAction, QIcon,QFileDialog,QMessageBox
# Initialize Qt resources from file resources.py
import resources
from qgis.core import QgsFeature,QgsFeatureRequest
# Import the code for the dialog
from Classification_dialog import randomForestDialog
import numpy as np
import os,sys

from osgeo import gdal,ogr,osr
from sklearn.ensemble import RandomForestClassifier


class randomForest:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """Constructor.

        :param iface: An interface instance that will be passed to this class
            which provides the hook by which you can manipulate the QGIS
            application at run time.
        :type iface: QgsInterface
        """
        # Save reference to the QGIS interface
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'randomForest_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)

            if qVersion() > '4.3.3':
                QCoreApplication.installTranslator(self.translator)


        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&randomForest')
        # TODO: We are going to let the user set this up in a future iteration
        self.toolbar = self.iface.addToolBar(u'randomForest')
        self.toolbar.setObjectName(u'randomForest')

    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        """Get the translation for a string using Qt translation API.

        We implement this ourselves since we do not inherit QObject.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('randomForest', message)


    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None):
        """Add a toolbar icon to the toolbar.

        :param icon_path: Path to the icon for this action. Can be a resource
            path (e.g. ':/plugins/foo/bar.png') or a normal file system path.
        :type icon_path: str

        :param text: Text that should be shown in menu items for this action.
        :type text: str

        :param callback: Function to be called when the action is triggered.
        :type callback: function

        :param enabled_flag: A flag indicating if the action should be enabled
            by default. Defaults to True.
        :type enabled_flag: bool

        :param add_to_menu: Flag indicating whether the action should also
            be added to the menu. Defaults to True.
        :type add_to_menu: bool

        :param add_to_toolbar: Flag indicating whether the action should also
            be added to the toolbar. Defaults to True.
        :type add_to_toolbar: bool

        :param status_tip: Optional text to show in a popup when mouse pointer
            hovers over the action.
        :type status_tip: str

        :param parent: Parent widget for the new action. Defaults None.
        :type parent: QWidget

        :param whats_this: Optional text to show in the status bar when the
            mouse pointer hovers over the action.

        :returns: The action that was created. Note that the action is also
            added to self.actions list.
        :rtype: QAction
        """

        # Create the dialog (after translation) and keep reference
        self.dlg = randomForestDialog()

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            self.toolbar.addAction(action)

        if add_to_menu:
            self.iface.addPluginToMenu(
                self.menu,
                action)

        self.actions.append(action)

        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""

        icon_path = ':/plugins/randomForest/icon.png'
        self.add_action(
            icon_path,
            text=self.tr(u'Classification with Random Forest'),
            callback=self.run,
            parent=self.iface.mainWindow())


    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr(u'&randomForest'),
                action)
            self.iface.removeToolBarIcon(action)
        # remove the toolbar
        del self.toolbar


    def OutputImage(self):
        self.output_fname = QFileDialog.getSaveFileName(self.dlg, "Define Output Image Folder and Name ","",'*.tif')
        self.dlg.lineEdit_3.setText(self.output_fname)
        return self.output_fname
    def OutputShape(self):
        self.filename_OS = QFileDialog.getSaveFileName(self.dlg, "Define Output Shapefile Folder and Name ","",'*.shp')
        self.dlg.lineEdit_4.setText(self.filename_OS)
    def select_training_data(self):
        self.train_data_path = QFileDialog.getExistingDirectory(self.dlg, "Select Training Data Folder","",)
        self.dlg.lineEdit_5.setText(self.train_data_path)
        return self.train_data_path

    def create_mask_from_vector(self,vector_data_path, cols, rows, geo_transform,
                            projection, target_value=1):
        """vektoru rasterize etmek icin (wrapper gdal.RasterizeLayer)."""
        data_source = gdal.OpenEx(vector_data_path, gdal.OF_VECTOR)
        layer = data_source.GetLayer(0)
        driver = gdal.GetDriverByName('MEM')
        target_ds = driver.Create('', cols, rows, 1, gdal.GDT_UInt16)
        target_ds.SetGeoTransform(geo_transform)
        target_ds.SetProjection(projection)
        gdal.RasterizeLayer(target_ds, [1], layer, burn_values=[target_value])
        return target_ds

    def vectors_to_raster(self,file_paths, rows, cols, geo_transform, projection):
        """tum vektorleri tek bir goruntude toplama"""
        labeled_pixels = np.zeros((rows, cols))
        for i, path in enumerate(file_paths):
            label = i+1
            ds = self.create_mask_from_vector(path, cols, rows, geo_transform,
                                         projection, target_value=label)
            band = ds.GetRasterBand(1)
            labeled_pixels += band.ReadAsArray()
            ds = None
        return labeled_pixels

    def write_geotiff(self,fname, data, geo_transform, projection):
        """veriden bir geotif uretme"""

        driver = gdal.GetDriverByName('GTiff')
        rows, cols = data.shape
        dataset = driver.Create(fname, cols, rows, 1, gdal.GDT_Byte)
        dataset.SetGeoTransform(geo_transform)
        dataset.SetProjection(projection)
        band = dataset.GetRasterBand(1)
        band.WriteArray(data)
        return dataset
        os.remove("foo.txt")

    def write_shapefiles(self,inputimage,shapepath,projection):
        src_ds = gdal.Open(inputimage)
        srcband = src_ds.GetRasterBand(1)
        dst_layername = "CLASSIFICATION_VECTOR"
        drv = ogr.GetDriverByName("ESRI Shapefile")
        dst_ds = drv.CreateDataSource(shapepath)

        spatialReference = osr.SpatialReference() #will create a spatial reference locally to tell the system what the reference will be
        spatialReference.ImportFromWkt(projection)

        dst_layer = dst_ds.CreateLayer(dst_layername, spatialReference)
        new_field = ogr.FieldDefn("Area", ogr.OFTReal)
        new_field.SetWidth(32)
        dst_layer.CreateField(new_field)

        gdal.Polygonize( srcband, None, dst_layer, -1, [], callback=None )

        for feature in dst_layer:
            geom = feature.GetGeometryRef()
            area = geom.GetArea()
            feature.SetField("Area", area)
            dst_layer.SetFeature(feature)
            if area < 1000000:
                dst_layer.DeleteFeature(feature.GetFID())
            elif area > 200000000:
                dst_layer.DeleteFeature(feature.GetFID())
            else:
                pass
        os.remove("foo2.txt")



    def run(self):
        """Run method that performs all the real work"""
        # show the dialog
        global srcband
        layers = self.iface.legendInterface().layers()
        layer_list = []
        for layer in layers:
            layer_list.append(layer.name())

        self.dlg.comboBox.addItems(layer_list)


        self.dlg.show()
        self.dlg.toolButton.clicked.connect(self.OutputImage)
        self.dlg.toolButton_2.clicked.connect(self.OutputShape)
        self.dlg.toolButton_3.clicked.connect(self.select_training_data)
        # Run the dialog event loop
        result = self.dlg.exec_()

        if result:
            # See if OK was pressed
#            self.raster_data_path = "C:\g1_crgbn.tif"
            fo = open("foo.txt", "wb")
            fo.close()
            fo2 = open("foo2.txt", "wb")
            fo2.close()
#            self.output_fname = r"C:\GokTurk\classification2.tiff"
#            self.train_data_path = r"C:\vectors"
            selectedLayerIndex = self.dlg.comboBox.currentIndex()
            raster_data_path = layers[selectedLayerIndex].source()

            raster_dataset = gdal.Open(raster_data_path, gdal.GA_ReadOnly)
            geo_transform = raster_dataset.GetGeoTransform()
            proj = raster_dataset.GetProjectionRef()
            bands_data = []
            for b in range(1, raster_dataset.RasterCount+1):
                band = raster_dataset.GetRasterBand(b)
                bands_data.append(band.ReadAsArray())

            bands_data = np.dstack(bands_data)
            rows, cols, n_bands = bands_data.shape

            files = [f for f in os.listdir(self.train_data_path) if f.endswith('.shp')]
            classes = [f.split('.')[0] for f in files]
            shapefiles = [os.path.join(self.train_data_path, f)
                          for f in files if f.endswith('.shp')]

            labeled_pixels = self.vectors_to_raster(shapefiles, rows, cols, geo_transform, proj)
            is_train = np.nonzero(labeled_pixels)
            training_labels = labeled_pixels[is_train]
            training_samples = bands_data[is_train]

            classifier = RandomForestClassifier(n_jobs= int(self.dlg.lineEdit.text()), n_estimators= int(self.dlg.lineEdit_2.text()))
            classifier.fit(training_samples, training_labels)

            n_samples = rows*cols

            flat_pixels = bands_data.reshape((n_samples, n_bands))
            result = classifier.predict(flat_pixels)

            classification = result.reshape((rows, cols))

            ### reshape ettikten sonra write_geotiff fonksiyonunu calistiralim)-----------------------
            self.write_geotiff(self.output_fname, classification, geo_transform, proj)

            if os.path.isfile("foo.txt") == True and self.dlg.checkBox.isChecked():
                layer = self.iface.addRasterLayer(self.output_fname, "Classified Raster Image")
                if not layer:
                    QMessageBox.information(None,"Uyari Ekrani","Eklenecek Classified Raster katmani bulunamadi!")
            else:
                pass

            ### Grüntü üretildikten sonra write_Shapefile fonksiyonunu calistiralim)------------------
            self.write_shapefiles(self.output_fname,self.filename_OS,proj)

            if os.path.isfile("foo2.txt") == False and self.dlg.checkBox_2.isChecked():
                layer = self.iface.addVectorLayer(self.filename_OS,"Classified Nominal Polygon", "ogr")
                if not layer:
                    QMessageBox.information(None,"Uyari Ekrani","Eklenecek ShapeFile katmani bulunamadi!")
            else:
                pass